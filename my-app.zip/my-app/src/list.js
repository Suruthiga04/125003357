const products=[
    {
        "productName":"Laptop 1",
        "price":2236,
        "rating":4.7,
        "discount":63,
        "availablity":"yes"
    },
    {
        "productName":"Laptop 13",
        "price": 1244,
        "rating": 4.5,
        "discount":45,
        "availablity":"out-of-stock"
    },
    {
        "productName": "Laptop 3",
        "price": 9102,
        "rating": 4.44,
        "discount": 98,
        "availablity": "out-of-stock"
    },
    {
        "productName": "Laptop 11",
        "price": 2652,
        "rating":4.12,
        "discount":70,
        "availablity":"yes"
    },
    {
        "productName": "Laptop 4",
        "price": 1258,
        "rating":3.8,
        "discount":33,
        "availablity":"yes"
    },
    {
        "productName": "Laptop 13",
        "price": 8686,
        "rating": 3.22,
        "discount": 24,
        "availablity": "out-of-stock"
    },
    {
        "productName": "Laptop 14",
        "price":9254,
        "rating":3,
        "discount":56,
        "availablity":"yes"
    },
    {
        "productName": "Laptop 1",
        "price":1059,
        "rating":2.77,
        "discount":21,
        "availablity":"yes"
    },
    {
        "productName": "Laptop 10",
        "price":7145,
        "rating":2.74,
        "discount":15,
        "availablity":"yes"
    },
    {
        "productName": "Laptop 10",
        "price":4101,
        "rating":2.67,
        "discount":37,
        "availablity":"out-of-stock"
    }
];

export default products;