import logo from "./logo.svg";
import "./App.css";
import React from "react";
import ProductList from "./product";

function App() {
  return (
    <div className="App">
      <h1>Top N Products</h1>
      <ProductList />
    </div>
  );
}

export default App;
