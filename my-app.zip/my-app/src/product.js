import React from "react";
import products from "./list";

const ProductList = () => {
  return (
    <div>
      {products.map((product) => (
        <div>
          <h2>{product.productName}</h2>
          <p>Price: ${product.price}</p>
          <p>Rating: {product.rating}</p>
          <p>Discount: {product.discount}%</p>
          <p>Availability: {product.availablity}</p>
        </div>
      ))}
    </div>
  );
};

export default ProductList;
